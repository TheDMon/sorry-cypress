declare module '@sorry-cypress/dashboard/resources/*.svg' {
  const content: string;
  export default content;
}
