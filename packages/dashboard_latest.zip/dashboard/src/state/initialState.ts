export const initialState = {
  navStructure: [],
};
