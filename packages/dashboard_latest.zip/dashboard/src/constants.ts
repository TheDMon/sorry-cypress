export const FORMAT = 'MMM dd yyyy, HH:mm:ss';
export const FORMAT_SHORTER = 'MMM dd, HH:mm';
export const IDLE_TIMEOUT_HOURS = 2;
